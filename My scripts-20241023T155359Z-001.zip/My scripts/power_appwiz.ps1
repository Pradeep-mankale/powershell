﻿appwiz.cpl
Start-Process powershell
