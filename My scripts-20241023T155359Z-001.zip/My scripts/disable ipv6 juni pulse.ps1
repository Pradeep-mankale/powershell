﻿disable-NetAdapterBinding -Name "Local Area Connection* 12" -ComponentID ms_tcpip6;
disable-NetAdapterBinding -Name "Local Area Connection* 12" -ComponentID jnprns