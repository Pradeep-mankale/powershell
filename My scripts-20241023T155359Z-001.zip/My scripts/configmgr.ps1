﻿Start-Process cmd.exe;
start-process -FilePath "C:\Windows\CCM\SCClient.exe";
Control smscfgrc 
