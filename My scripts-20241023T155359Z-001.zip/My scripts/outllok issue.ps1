﻿Rename-Item "HKCU:\Software\Microsoft\Office\16.0"  old16.0
Rename-Item "HKCU:\Software\Microsoft\Office"  oldoffice