﻿Start-Process -FilePath "C:\Windows\CCM\CMTrace" -ArgumentList "C:\Windows\CCM\Logs\WUAHandler.log" -InformationAction SilentlyContinue;
eventvwr
