﻿$hash = @{process= "Get-Process goog*"
service= "Get-Service prote*"
}
write-output $hash