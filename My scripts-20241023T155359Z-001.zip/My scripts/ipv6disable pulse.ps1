﻿disable-NetAdapterBinding -Name "Local*" -ComponentID ms_tcpip6
 